package com.HelloWorklight;

public class GCMIntentService extends com.worklight.androidgap.push.GCMIntentService{
	//Nothing to do here...
}
